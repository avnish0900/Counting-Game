import React from "react"
function Header() {
  //this.props=props;
  return (
    <div>
      <header>
        <img  src="http://www.pngall.com/wp-content/uploads/2016/05/Trollface.png" width="10%"
        alt="Problem ?"
        />
        <p>
      meme generator
      </p>
    </header>
   </div>
  )
}
      
export default Header
