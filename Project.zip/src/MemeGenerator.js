import React,{Component} from "react"
class MemeGenerator extends Component {
  constructor() {
    super()
    this.state={
      topText:"",
      bottomText:"",
      randomImg : "http://i.imgflip.com/1bij.jpg",
      allMemeImg:[]
    }
    this.handleChange=this.handleChange.bind(this)
  }
  componentDidMount() {
    fetch("http://api.imgflip.com/get_memes")
    .then(response => response.json())
    .then(response =>{
      const{memes}=response.data
      console.log(memes[0])
      this.setState({allMemeImg: memes})
    })
  }
  handleChange(event) {
    const{name,value}=event.target
    this.setState({[name]:value})
  }
  render() {
    return (
      <div>
      <form>
      <input 
        type="text"
        name="topText"
        placeholder="Top Text"
        value={this.state.topText}
        onChange={this.handleChange}
        />
        <input 
        type="text"
        name="bottomText"
        placeholder="Bottom Text"
        value={this.state.bottomText}
        onChange={this.handleChange}
        />
        <button> GENERATE</button>
      </form>
      <div>
      
      



      <img src={this.state.randomImg}  alt="" style={{width:"100%"}}/>
      <div style={{
  position: "absolute",
  top: "8px",
  left: "16px",
}}
>Top Left</div>
      
      <h3> {this.state.topText}</h3>
      <h3> {this.state.bottomText}</h3>
       </div>
       </div>
    )
  }


}
export default MemeGenerator
