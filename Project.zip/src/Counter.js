import React, { Component } from 'react';
class Counter extends Component {
  state = {
    count: 0
  };
  styles = {
    fontSize: 40,
    fontWeight: "bold",
    textAlign: "center",
    buttonAlign: "center",
    top: "center",
    left: "auto",
  };
  handleIncrement = () => {
    this.setState({ count: this.state.count + 1 })
  };
  handleDelete = () => {
    this.setState({ count: this.state.count - 1 })
  };
  handleReset = () => {
    this.setState({ count: this.state.count = 0 })
  };
  render() {
    return (<div style={this.styles}>
      <button style={{ padding: "15px 40px", fontSize: 30, backgroundColor: "blue" }} onClick={this.handleReset}>Reset </button>
      <br />
      <br />
      <span >{this.formatCount()} </span>
      <br />
      <br />
      <button style={{ padding: "15px 40px", fontSize: 30, backgroundColor: "green" }} onClick={this.handleIncrement}> Increment </button>
      <br />
      <br />
      <button style={{ padding: "15px 40px", fontSize: 30, backgroundColor: "red" }}
        onClick={this.handleDelete} >Delete</button>
    </div>
    );
  }
  formatCount() {
    const { count } = this.state;
    return count <= 0 ? <p1> Zero</p1> : count;
  }
}
export default Counter;
